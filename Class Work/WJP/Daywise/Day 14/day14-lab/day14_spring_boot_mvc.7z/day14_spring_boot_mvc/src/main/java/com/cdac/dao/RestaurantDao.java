package com.cdac.dao;

import java.util.List;

import com.cdac.entities.Restaurant;

public interface RestaurantDao {
//add a method to get all restaurants
	List<Restaurant> getAllRestaurants();
	
}
